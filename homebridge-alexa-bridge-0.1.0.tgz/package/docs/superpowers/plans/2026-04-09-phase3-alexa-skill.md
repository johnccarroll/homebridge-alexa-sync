# Phase 3: Alexa Smart Home Skill — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enable two-way Alexa voice control by adding a local API server to the plugin and an AWS Lambda Smart Home Skill handler that translates Alexa directives into device commands.

**Architecture:** The Homebridge plugin runs a lightweight HTTP API server on the Pi. The AWS Lambda receives Alexa Smart Home directives, calls the Pi's API, and returns Alexa-formatted responses. All device types supported by the plugin (lights, switches, thermostats, etc.) are automatically exposed to Alexa via the skill's Discovery response. State changes from HomeKit propagate to Alexa via the skill's ReportState handler.

**Tech Stack:** TypeScript, Node.js 20+, AWS Lambda (ESM), Vitest

**Infrastructure (already set up):**
- Lambda ARN: `arn:aws:lambda:us-east-1:404147232960:function:alexa-smart-home-bridge`
- Skill ID: `amzn1.ask.skill.12c825c8-d63a-434a-a1fb-73e2d1d1db5e`
- LWA Client ID/Secret: stored in env vars

---

## File Structure

```
src/
├── api-server.ts                  # Local HTTP API server (runs on Pi)
├── alexa-skill/
│   ├── handler.ts                 # Alexa directive router
│   ├── discovery.ts               # Discovery directive → response
│   └── control.ts                 # Control/ReportState directives → response

alexa-lambda/
└── index.mjs                      # AWS Lambda handler (thin proxy)

test/
├── api-server.test.ts
└── alexa-skill/
    ├── handler.test.ts
    ├── discovery.test.ts
    └── control.test.ts
```

**Files modified:**
- `src/platform.ts` — start API server after init
- `src/config.ts` — add `alexaSkill` config section
- `package.json` — no new deps (uses Node.js built-in `http`)

---

### Task 1: Config and Types for Alexa Skill

**Files:**
- Modify: `src/config.ts`

- [ ] **Step 1: Add AlexaSkillConfig to config.ts**

Add after `AlexaConfig`:

```typescript
export interface AlexaSkillConfig {
  enabled?: boolean;
  apiPort?: number;
  apiKey?: string;
}
```

Update `PluginConfig`:

```typescript
export interface PluginConfig {
  name: string;
  providers?: {
    tuya?: TuyaConfig;
    alexa?: AlexaConfig;
  };
  alexaSkill?: AlexaSkillConfig;
}
```

- [ ] **Step 2: Update config.schema.json**

Add at the top level of `schema.properties` (not inside `providers`):

```json
"alexaSkill": {
  "title": "Alexa Smart Home Skill (Two-Way Sync)",
  "type": "object",
  "properties": {
    "enabled": { "title": "Enable Alexa Skill API", "type": "boolean", "default": false },
    "apiPort": { "title": "API Server Port", "type": "number", "default": 9090 },
    "apiKey": { "title": "API Key (shared secret with Lambda)", "type": "string" }
  }
}
```

- [ ] **Step 3: Verify build**

Run: `npm run build`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/config.ts config.schema.json
git commit -m "feat: add AlexaSkillConfig for two-way sync API"
```

---

### Task 2: Local API Server

**Files:**
- Create: `src/api-server.ts`
- Create: `test/api-server.test.ts`

- [ ] **Step 1: Write API server tests**

```typescript
// test/api-server.test.ts
import { describe, it, expect, vi, beforeAll, afterAll } from 'vitest';
import { ApiServer } from '../src/api-server.js';
import type { DeviceManager } from '../src/device-manager.js';
import type { BridgeDevice, DeviceState } from '../src/types.js';

const LIGHT: BridgeDevice = {
  id: 'tuya:dev_001',
  name: 'Kitchen Light',
  type: 'light',
  provider: 'tuya',
  capabilities: [
    { type: 'on-off' },
    { type: 'brightness', range: [0, 100] },
    { type: 'color' },
    { type: 'color-temperature', range: [2700, 6500] },
  ],
  manufacturer: 'Tuya',
  model: 'prod_1',
};

function mockDeviceManager(): DeviceManager {
  return {
    getAllDevices: vi.fn().mockReturnValue([LIGHT]),
    getDevice: vi.fn((id: string) => id === 'tuya:dev_001' ? LIGHT : undefined),
    getState: vi.fn().mockResolvedValue({ on: true, brightness: 75, hue: 0, saturation: 0, colorTemperature: 4000 }),
    setState: vi.fn().mockResolvedValue(undefined),
    discoverAll: vi.fn().mockResolvedValue([LIGHT]),
    invalidateCache: vi.fn(),
    dispose: vi.fn(),
    onStateChange: vi.fn(),
  } as unknown as DeviceManager;
}

describe('ApiServer', () => {
  let server: ApiServer;
  let dm: DeviceManager;
  const PORT = 19090; // Use high port for tests

  beforeAll(async () => {
    dm = mockDeviceManager();
    server = new ApiServer(dm, { port: PORT, apiKey: 'test-key' });
    await server.start();
  });

  afterAll(async () => {
    await server.stop();
  });

  it('rejects requests without API key', async () => {
    const res = await fetch(`http://127.0.0.1:${PORT}/devices`);
    expect(res.status).toBe(401);
  });

  it('GET /devices returns all devices', async () => {
    const res = await fetch(`http://127.0.0.1:${PORT}/devices`, {
      headers: { 'x-api-key': 'test-key' },
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data).toHaveLength(1);
    expect(data[0].id).toBe('tuya:dev_001');
  });

  it('GET /devices/:id/state returns device state', async () => {
    const res = await fetch(`http://127.0.0.1:${PORT}/devices/tuya:dev_001/state`, {
      headers: { 'x-api-key': 'test-key' },
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.on).toBe(true);
    expect(data.brightness).toBe(75);
  });

  it('PUT /devices/:id/state sets device state', async () => {
    const res = await fetch(`http://127.0.0.1:${PORT}/devices/tuya:dev_001/state`, {
      method: 'PUT',
      headers: { 'x-api-key': 'test-key', 'Content-Type': 'application/json' },
      body: JSON.stringify({ on: false }),
    });
    expect(res.status).toBe(200);
    expect(dm.setState).toHaveBeenCalledWith('tuya:dev_001', { on: false });
  });

  it('returns 404 for unknown device', async () => {
    const res = await fetch(`http://127.0.0.1:${PORT}/devices/unknown:123/state`, {
      headers: { 'x-api-key': 'test-key' },
    });
    expect(res.status).toBe(404);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run test/api-server.test.ts`
Expected: FAIL — cannot find module

- [ ] **Step 3: Implement API server**

```typescript
// src/api-server.ts
import { createServer, type IncomingMessage, type ServerResponse, type Server } from 'node:http';
import type { DeviceManager } from './device-manager.js';

interface ApiServerConfig {
  port: number;
  apiKey: string;
}

export class ApiServer {
  private server: Server | null = null;
  private readonly dm: DeviceManager;
  private readonly config: ApiServerConfig;

  constructor(dm: DeviceManager, config: ApiServerConfig) {
    this.dm = dm;
    this.config = config;
  }

  async start(): Promise<void> {
    return new Promise((resolve) => {
      this.server = createServer((req, res) => this.handleRequest(req, res));
      this.server.listen(this.config.port, '0.0.0.0', () => resolve());
    });
  }

  async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => resolve());
      } else {
        resolve();
      }
    });
  }

  private async handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
    // Auth check
    if (req.headers['x-api-key'] !== this.config.apiKey) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
      return;
    }

    const url = new URL(req.url ?? '/', `http://${req.headers.host}`);
    const path = url.pathname;

    try {
      if (req.method === 'GET' && path === '/devices') {
        const devices = this.dm.getAllDevices();
        this.json(res, 200, devices);
      } else if (req.method === 'GET' && path.match(/^\/devices\/(.+)\/state$/)) {
        const deviceId = decodeURIComponent(path.match(/^\/devices\/(.+)\/state$/)![1]);
        const device = this.dm.getDevice(deviceId);
        if (!device) {
          this.json(res, 404, { error: 'Device not found' });
          return;
        }
        const state = await this.dm.getState(deviceId);
        this.json(res, 200, state);
      } else if (req.method === 'PUT' && path.match(/^\/devices\/(.+)\/state$/)) {
        const deviceId = decodeURIComponent(path.match(/^\/devices\/(.+)\/state$/)![1]);
        const device = this.dm.getDevice(deviceId);
        if (!device) {
          this.json(res, 404, { error: 'Device not found' });
          return;
        }
        const body = await this.readBody(req);
        const state = JSON.parse(body);
        await this.dm.setState(deviceId, state);
        this.json(res, 200, { ok: true });
      } else {
        this.json(res, 404, { error: 'Not found' });
      }
    } catch (err) {
      this.json(res, 500, { error: (err as Error).message });
    }
  }

  private json(res: ServerResponse, status: number, data: unknown): void {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  }

  private readBody(req: IncomingMessage): Promise<string> {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', (chunk: Buffer) => { body += chunk.toString(); });
      req.on('end', () => resolve(body));
      req.on('error', reject);
    });
  }
}
```

- [ ] **Step 4: Run tests**

Run: `npx vitest run test/api-server.test.ts`
Expected: PASS (all 5 tests)

- [ ] **Step 5: Commit**

```bash
git add src/api-server.ts test/api-server.test.ts
git commit -m "feat: add local HTTP API server for Alexa Skill bridge"
```

---

### Task 3: Alexa Discovery Handler

**Files:**
- Create: `src/alexa-skill/discovery.ts`
- Create: `test/alexa-skill/discovery.test.ts`

- [ ] **Step 1: Write discovery tests**

```typescript
// test/alexa-skill/discovery.test.ts
import { describe, it, expect } from 'vitest';
import { buildDiscoveryResponse } from '../../src/alexa-skill/discovery.js';
import type { BridgeDevice } from '../../src/types.js';

const LIGHT: BridgeDevice = {
  id: 'tuya:dev_001',
  name: 'Kitchen Light',
  type: 'light',
  provider: 'tuya',
  capabilities: [
    { type: 'on-off' },
    { type: 'brightness', range: [0, 100] },
    { type: 'color' },
    { type: 'color-temperature', range: [2700, 6500] },
  ],
  manufacturer: 'Tuya',
  model: 'Smart Bulb',
};

const OUTLET: BridgeDevice = {
  id: 'alexa:plug_001',
  name: 'Desk Plug',
  type: 'outlet',
  provider: 'alexa',
  capabilities: [{ type: 'on-off' }],
};

describe('buildDiscoveryResponse', () => {
  it('builds valid Alexa Discovery.Response', () => {
    const response = buildDiscoveryResponse([LIGHT, OUTLET]);

    expect(response.event.header.namespace).toBe('Alexa.Discovery');
    expect(response.event.header.name).toBe('Discover.Response');
    expect(response.event.header.payloadVersion).toBe('3');
    expect(response.event.payload.endpoints).toHaveLength(2);
  });

  it('maps light with all capabilities', () => {
    const response = buildDiscoveryResponse([LIGHT]);
    const endpoint = response.event.payload.endpoints[0];

    expect(endpoint.endpointId).toBe('tuya:dev_001');
    expect(endpoint.friendlyName).toBe('Kitchen Light');
    expect(endpoint.manufacturerName).toBe('Tuya');
    expect(endpoint.displayCategories).toContain('LIGHT');

    const capabilityInterfaces = endpoint.capabilities.map((c: any) => c.interface);
    expect(capabilityInterfaces).toContain('Alexa.PowerController');
    expect(capabilityInterfaces).toContain('Alexa.BrightnessController');
    expect(capabilityInterfaces).toContain('Alexa.ColorController');
    expect(capabilityInterfaces).toContain('Alexa.ColorTemperatureController');
    expect(capabilityInterfaces).toContain('Alexa');
  });

  it('maps outlet with on-off only', () => {
    const response = buildDiscoveryResponse([OUTLET]);
    const endpoint = response.event.payload.endpoints[0];

    expect(endpoint.displayCategories).toContain('SMARTPLUG');
    const capabilityInterfaces = endpoint.capabilities.map((c: any) => c.interface);
    expect(capabilityInterfaces).toContain('Alexa.PowerController');
    expect(capabilityInterfaces).not.toContain('Alexa.BrightnessController');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run test/alexa-skill/discovery.test.ts`
Expected: FAIL

- [ ] **Step 3: Implement discovery handler**

```typescript
// src/alexa-skill/discovery.ts
import type { BridgeDevice, DeviceType } from '../types.js';
import { randomUUID } from 'node:crypto';

const DEVICE_TYPE_TO_CATEGORY: Record<DeviceType, string> = {
  light: 'LIGHT',
  switch: 'SWITCH',
  outlet: 'SMARTPLUG',
  lock: 'SMARTLOCK',
  fan: 'FAN',
  thermostat: 'THERMOSTAT',
};

function buildCapabilities(device: BridgeDevice): object[] {
  const caps: object[] = [];

  // Always include Alexa interface
  caps.push({
    type: 'AlexaInterface',
    interface: 'Alexa',
    version: '3',
  });

  for (const cap of device.capabilities) {
    switch (cap.type) {
      case 'on-off':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.PowerController',
          version: '3',
          properties: {
            supported: [{ name: 'powerState' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'brightness':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.BrightnessController',
          version: '3',
          properties: {
            supported: [{ name: 'brightness' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'color':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.ColorController',
          version: '3',
          properties: {
            supported: [{ name: 'color' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'color-temperature':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.ColorTemperatureController',
          version: '3',
          properties: {
            supported: [{ name: 'colorTemperatureInKelvin' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'temperature':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.TemperatureSensor',
          version: '3',
          properties: {
            supported: [{ name: 'temperature' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'target-temperature':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.ThermostatController',
          version: '3',
          properties: {
            supported: [{ name: 'targetSetpoint' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
      case 'lock':
        caps.push({
          type: 'AlexaInterface',
          interface: 'Alexa.LockController',
          version: '3',
          properties: {
            supported: [{ name: 'lockState' }],
            proactivelyReported: false,
            retrievable: true,
          },
        });
        break;
    }
  }

  return caps;
}

export function buildDiscoveryResponse(devices: BridgeDevice[]): any {
  const endpoints = devices.map(device => ({
    endpointId: device.id,
    manufacturerName: device.manufacturer ?? 'Homebridge',
    description: `${device.name} via Alexa Bridge`,
    friendlyName: device.name,
    displayCategories: [DEVICE_TYPE_TO_CATEGORY[device.type] ?? 'OTHER'],
    capabilities: buildCapabilities(device),
  }));

  return {
    event: {
      header: {
        namespace: 'Alexa.Discovery',
        name: 'Discover.Response',
        payloadVersion: '3',
        messageId: randomUUID(),
      },
      payload: { endpoints },
    },
  };
}
```

- [ ] **Step 4: Run tests**

Run: `npx vitest run test/alexa-skill/discovery.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/alexa-skill/discovery.ts test/alexa-skill/discovery.test.ts
git commit -m "feat: add Alexa Smart Home Discovery response builder"
```

---

### Task 4: Alexa Control and StateReport Handlers

**Files:**
- Create: `src/alexa-skill/control.ts`
- Create: `test/alexa-skill/control.test.ts`

- [ ] **Step 1: Write control handler tests**

```typescript
// test/alexa-skill/control.test.ts
import { describe, it, expect } from 'vitest';
import {
  buildControlResponse,
  buildStateReportResponse,
  extractStateFromDirective,
} from '../../src/alexa-skill/control.js';
import type { DeviceState } from '../../src/types.js';

describe('extractStateFromDirective', () => {
  it('extracts TurnOn', () => {
    const directive = {
      header: { namespace: 'Alexa.PowerController', name: 'TurnOn' },
      endpoint: { endpointId: 'dev_001' },
    };
    expect(extractStateFromDirective(directive)).toEqual({ on: true });
  });

  it('extracts TurnOff', () => {
    const directive = {
      header: { namespace: 'Alexa.PowerController', name: 'TurnOff' },
      endpoint: { endpointId: 'dev_001' },
    };
    expect(extractStateFromDirective(directive)).toEqual({ on: false });
  });

  it('extracts SetBrightness', () => {
    const directive = {
      header: { namespace: 'Alexa.BrightnessController', name: 'SetBrightness' },
      endpoint: { endpointId: 'dev_001' },
      payload: { brightness: 50 },
    };
    expect(extractStateFromDirective(directive)).toEqual({ brightness: 50 });
  });

  it('extracts SetColor', () => {
    const directive = {
      header: { namespace: 'Alexa.ColorController', name: 'SetColor' },
      endpoint: { endpointId: 'dev_001' },
      payload: { color: { hue: 120, saturation: 0.8, brightness: 1.0 } },
    };
    expect(extractStateFromDirective(directive)).toEqual({ hue: 120, saturation: 80 });
  });

  it('extracts SetColorTemperature', () => {
    const directive = {
      header: { namespace: 'Alexa.ColorTemperatureController', name: 'SetColorTemperature' },
      endpoint: { endpointId: 'dev_001' },
      payload: { colorTemperatureInKelvin: 4000 },
    };
    expect(extractStateFromDirective(directive)).toEqual({ colorTemperature: 4000 });
  });
});

describe('buildControlResponse', () => {
  it('builds valid Alexa.Response with context properties', () => {
    const state: DeviceState = { on: true, brightness: 75, colorTemperature: 4000 };
    const response = buildControlResponse('dev_001', 'corr-123', state);

    expect(response.event.header.namespace).toBe('Alexa');
    expect(response.event.header.name).toBe('Response');
    expect(response.event.header.correlationToken).toBe('corr-123');
    expect(response.event.endpoint.endpointId).toBe('dev_001');

    const propNames = response.context.properties.map((p: any) => `${p.namespace}.${p.name}`);
    expect(propNames).toContain('Alexa.PowerController.powerState');
    expect(propNames).toContain('Alexa.BrightnessController.brightness');
    expect(propNames).toContain('Alexa.ColorTemperatureController.colorTemperatureInKelvin');
  });
});

describe('buildStateReportResponse', () => {
  it('builds valid Alexa.StateReport', () => {
    const state: DeviceState = { on: false };
    const response = buildStateReportResponse('dev_001', 'corr-456', state);

    expect(response.event.header.name).toBe('StateReport');
    expect(response.event.endpoint.endpointId).toBe('dev_001');
    expect(response.context.properties[0].value).toBe('OFF');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run test/alexa-skill/control.test.ts`
Expected: FAIL

- [ ] **Step 3: Implement control handlers**

```typescript
// src/alexa-skill/control.ts
import type { DeviceState } from '../types.js';
import { randomUUID } from 'node:crypto';

export function extractStateFromDirective(directive: any): Partial<DeviceState> {
  const { namespace, name } = directive.header;

  switch (namespace) {
    case 'Alexa.PowerController':
      return { on: name === 'TurnOn' };
    case 'Alexa.BrightnessController':
      return { brightness: directive.payload.brightness };
    case 'Alexa.ColorController': {
      const c = directive.payload.color;
      return { hue: c.hue, saturation: Math.round(c.saturation * 100) };
    }
    case 'Alexa.ColorTemperatureController':
      return { colorTemperature: directive.payload.colorTemperatureInKelvin };
    default:
      return {};
  }
}

function stateToProperties(state: DeviceState): object[] {
  const now = new Date().toISOString();
  const props: object[] = [];

  if (state.on !== undefined) {
    props.push({
      namespace: 'Alexa.PowerController',
      name: 'powerState',
      value: state.on ? 'ON' : 'OFF',
      timeOfSample: now,
      uncertaintyInMilliseconds: 500,
    });
  }
  if (state.brightness !== undefined) {
    props.push({
      namespace: 'Alexa.BrightnessController',
      name: 'brightness',
      value: state.brightness,
      timeOfSample: now,
      uncertaintyInMilliseconds: 500,
    });
  }
  if (state.hue !== undefined && state.saturation !== undefined) {
    props.push({
      namespace: 'Alexa.ColorController',
      name: 'color',
      value: { hue: state.hue, saturation: state.saturation / 100, brightness: 1.0 },
      timeOfSample: now,
      uncertaintyInMilliseconds: 500,
    });
  }
  if (state.colorTemperature !== undefined) {
    props.push({
      namespace: 'Alexa.ColorTemperatureController',
      name: 'colorTemperatureInKelvin',
      value: state.colorTemperature,
      timeOfSample: now,
      uncertaintyInMilliseconds: 500,
    });
  }

  return props;
}

export function buildControlResponse(endpointId: string, correlationToken: string, state: DeviceState): any {
  return {
    context: { properties: stateToProperties(state) },
    event: {
      header: {
        namespace: 'Alexa',
        name: 'Response',
        payloadVersion: '3',
        messageId: randomUUID(),
        correlationToken,
      },
      endpoint: { endpointId },
      payload: {},
    },
  };
}

export function buildStateReportResponse(endpointId: string, correlationToken: string, state: DeviceState): any {
  return {
    context: { properties: stateToProperties(state) },
    event: {
      header: {
        namespace: 'Alexa',
        name: 'StateReport',
        payloadVersion: '3',
        messageId: randomUUID(),
        correlationToken,
      },
      endpoint: { endpointId },
      payload: {},
    },
  };
}
```

- [ ] **Step 4: Run tests**

Run: `npx vitest run test/alexa-skill/control.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/alexa-skill/control.ts test/alexa-skill/control.test.ts
git commit -m "feat: add Alexa control and state report response builders"
```

---

### Task 5: Alexa Directive Router

**Files:**
- Create: `src/alexa-skill/handler.ts`
- Create: `test/alexa-skill/handler.test.ts`

- [ ] **Step 1: Write handler tests**

```typescript
// test/alexa-skill/handler.test.ts
import { describe, it, expect, vi } from 'vitest';
import { handleAlexaDirective } from '../../src/alexa-skill/handler.js';
import type { DeviceManager } from '../../src/device-manager.js';
import type { BridgeDevice } from '../../src/types.js';

const LIGHT: BridgeDevice = {
  id: 'tuya:dev_001',
  name: 'Kitchen Light',
  type: 'light',
  provider: 'tuya',
  capabilities: [
    { type: 'on-off' },
    { type: 'brightness', range: [0, 100] },
    { type: 'color' },
    { type: 'color-temperature', range: [2700, 6500] },
  ],
  manufacturer: 'Tuya',
};

function mockDM(): DeviceManager {
  return {
    getAllDevices: vi.fn().mockReturnValue([LIGHT]),
    getDevice: vi.fn().mockReturnValue(LIGHT),
    getState: vi.fn().mockResolvedValue({ on: true, brightness: 75, colorTemperature: 4000 }),
    setState: vi.fn().mockResolvedValue(undefined),
  } as unknown as DeviceManager;
}

describe('handleAlexaDirective', () => {
  it('handles Discovery', async () => {
    const dm = mockDM();
    const directive = {
      directive: {
        header: { namespace: 'Alexa.Discovery', name: 'Discover', payloadVersion: '3', messageId: 'msg-1' },
        payload: { scope: { type: 'BearerToken', token: 'tok' } },
      },
    };

    const response = await handleAlexaDirective(directive, dm);
    expect(response.event.header.name).toBe('Discover.Response');
    expect(response.event.payload.endpoints).toHaveLength(1);
  });

  it('handles TurnOn', async () => {
    const dm = mockDM();
    const directive = {
      directive: {
        header: { namespace: 'Alexa.PowerController', name: 'TurnOn', correlationToken: 'corr-1', messageId: 'msg-2' },
        endpoint: { endpointId: 'tuya:dev_001' },
      },
    };

    const response = await handleAlexaDirective(directive, dm);
    expect(response.event.header.name).toBe('Response');
    expect(dm.setState).toHaveBeenCalledWith('tuya:dev_001', { on: true });
  });

  it('handles SetBrightness', async () => {
    const dm = mockDM();
    const directive = {
      directive: {
        header: { namespace: 'Alexa.BrightnessController', name: 'SetBrightness', correlationToken: 'corr-2', messageId: 'msg-3' },
        endpoint: { endpointId: 'tuya:dev_001' },
        payload: { brightness: 50 },
      },
    };

    const response = await handleAlexaDirective(directive, dm);
    expect(dm.setState).toHaveBeenCalledWith('tuya:dev_001', { brightness: 50 });
  });

  it('handles ReportState', async () => {
    const dm = mockDM();
    const directive = {
      directive: {
        header: { namespace: 'Alexa', name: 'ReportState', correlationToken: 'corr-3', messageId: 'msg-4' },
        endpoint: { endpointId: 'tuya:dev_001' },
      },
    };

    const response = await handleAlexaDirective(directive, dm);
    expect(response.event.header.name).toBe('StateReport');
    expect(response.context.properties.length).toBeGreaterThan(0);
  });

  it('returns ErrorResponse for unknown device', async () => {
    const dm = mockDM();
    (dm.getDevice as any).mockReturnValue(undefined);
    (dm.setState as any).mockRejectedValue(new Error('Unknown device'));

    const directive = {
      directive: {
        header: { namespace: 'Alexa.PowerController', name: 'TurnOn', correlationToken: 'corr-4', messageId: 'msg-5' },
        endpoint: { endpointId: 'unknown:123' },
      },
    };

    const response = await handleAlexaDirective(directive, dm);
    expect(response.event.header.name).toBe('ErrorResponse');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run test/alexa-skill/handler.test.ts`
Expected: FAIL

- [ ] **Step 3: Implement directive router**

```typescript
// src/alexa-skill/handler.ts
import type { DeviceManager } from '../device-manager.js';
import { buildDiscoveryResponse } from './discovery.js';
import { extractStateFromDirective, buildControlResponse, buildStateReportResponse } from './control.js';
import { randomUUID } from 'node:crypto';

export async function handleAlexaDirective(event: any, dm: DeviceManager): Promise<any> {
  const directive = event.directive;
  const { namespace, name, correlationToken } = directive.header;

  // Discovery
  if (namespace === 'Alexa.Discovery' && name === 'Discover') {
    const devices = dm.getAllDevices();
    return buildDiscoveryResponse(devices);
  }

  // ReportState
  if (namespace === 'Alexa' && name === 'ReportState') {
    const endpointId = directive.endpoint.endpointId;
    try {
      const state = await dm.getState(endpointId);
      return buildStateReportResponse(endpointId, correlationToken, state);
    } catch {
      return buildErrorResponse('NO_SUCH_ENDPOINT', `Device ${endpointId} not found`, correlationToken, endpointId);
    }
  }

  // Control directives
  const endpointId = directive.endpoint?.endpointId;
  if (!endpointId) {
    return buildErrorResponse('INVALID_DIRECTIVE', 'Missing endpoint', correlationToken);
  }

  try {
    const stateChange = extractStateFromDirective(directive);
    if (Object.keys(stateChange).length > 0) {
      await dm.setState(endpointId, stateChange);
    }
    const currentState = await dm.getState(endpointId);
    return buildControlResponse(endpointId, correlationToken, currentState);
  } catch (err) {
    return buildErrorResponse(
      'ENDPOINT_UNREACHABLE',
      (err as Error).message,
      correlationToken,
      endpointId,
    );
  }
}

function buildErrorResponse(type: string, message: string, correlationToken?: string, endpointId?: string): any {
  const response: any = {
    event: {
      header: {
        namespace: 'Alexa',
        name: 'ErrorResponse',
        payloadVersion: '3',
        messageId: randomUUID(),
      },
      payload: { type, message },
    },
  };
  if (correlationToken) response.event.header.correlationToken = correlationToken;
  if (endpointId) response.event.endpoint = { endpointId };
  return response;
}
```

- [ ] **Step 4: Run tests**

Run: `npx vitest run test/alexa-skill/handler.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/alexa-skill/handler.ts test/alexa-skill/handler.test.ts
git commit -m "feat: add Alexa directive router with error handling"
```

---

### Task 6: Platform Integration (API Server)

**Files:**
- Modify: `src/platform.ts`

- [ ] **Step 1: Wire API server into platform**

Add import:
```typescript
import { ApiServer } from './api-server.js';
```

Add private field:
```typescript
private apiServer?: ApiServer;
```

At the end of the `init()` method, after `this.startPolling(pluginConfig)`, add:

```typescript
    // Start API server for Alexa Smart Home Skill
    if (pluginConfig.alexaSkill?.enabled && pluginConfig.alexaSkill?.apiKey) {
      const port = pluginConfig.alexaSkill.apiPort ?? 9090;
      this.apiServer = new ApiServer(this.deviceManager, {
        port,
        apiKey: pluginConfig.alexaSkill.apiKey,
      });
      await this.apiServer.start();
      this.log.info(`Alexa Skill API server running on port ${port}`);
    }
```

- [ ] **Step 2: Verify build**

Run: `npm run build`
Expected: No errors

- [ ] **Step 3: Run all tests**

Run: `npx vitest run`
Expected: All pass

- [ ] **Step 4: Commit**

```bash
git add src/platform.ts
git commit -m "feat: start API server from platform when Alexa Skill is enabled"
```

---

### Task 7: AWS Lambda Handler

**Files:**
- Create: `alexa-lambda/index.mjs`

- [ ] **Step 1: Create the Lambda handler**

```javascript
// alexa-lambda/index.mjs
// Thin proxy — forwards Alexa Smart Home directives to the plugin's API server.
// Set BRIDGE_URL and BRIDGE_API_KEY as Lambda environment variables.

const BRIDGE_URL = process.env.BRIDGE_URL; // e.g., 'http://100.x.x.x:9090'
const BRIDGE_API_KEY = process.env.BRIDGE_API_KEY;

export const handler = async (event) => {
  if (!BRIDGE_URL) {
    return errorResponse('INTERNAL_ERROR', 'BRIDGE_URL not configured');
  }

  const directive = event.directive;
  const { namespace, name } = directive.header;

  // Discovery — get all devices and build response
  if (namespace === 'Alexa.Discovery' && name === 'Discover') {
    const res = await apiFetch('GET', '/devices');
    if (!res.ok) return errorResponse('INTERNAL_ERROR', 'Failed to fetch devices');
    const devices = await res.json();
    // Forward to the handler endpoint
    const handlerRes = await apiFetch('POST', '/alexa/directive', event);
    if (!handlerRes.ok) return errorResponse('INTERNAL_ERROR', 'Handler failed');
    return handlerRes.json();
  }

  // All other directives — forward to handler
  const res = await apiFetch('POST', '/alexa/directive', event);
  if (!res.ok) return errorResponse('ENDPOINT_UNREACHABLE', 'Bridge unreachable');
  return res.json();
};

async function apiFetch(method, path, body) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': BRIDGE_API_KEY,
    },
  };
  if (body) options.body = JSON.stringify(body);
  return fetch(`${BRIDGE_URL}${path}`, options);
}

function errorResponse(type, message) {
  return {
    event: {
      header: {
        namespace: 'Alexa',
        name: 'ErrorResponse',
        payloadVersion: '3',
        messageId: crypto.randomUUID(),
      },
      payload: { type, message },
    },
  };
}
```

- [ ] **Step 2: Commit**

```bash
git add alexa-lambda/index.mjs
git commit -m "feat: add AWS Lambda handler for Alexa Smart Home Skill"
```

---

### Task 8: Add Directive Endpoint to API Server

**Files:**
- Modify: `src/api-server.ts`
- Modify: `test/api-server.test.ts`

- [ ] **Step 1: Add directive handling to API server**

Add import in `api-server.ts`:
```typescript
import { handleAlexaDirective } from './alexa-skill/handler.js';
```

In the `handleRequest` method, add a new route before the final `else` 404 block:

```typescript
      } else if (req.method === 'POST' && path === '/alexa/directive') {
        const body = await this.readBody(req);
        const event = JSON.parse(body);
        const response = await handleAlexaDirective(event, this.dm);
        this.json(res, 200, response);
```

- [ ] **Step 2: Add test for directive endpoint**

Add to `test/api-server.test.ts`, inside the describe block:

```typescript
  it('POST /alexa/directive handles Discovery', async () => {
    const directive = {
      directive: {
        header: { namespace: 'Alexa.Discovery', name: 'Discover', payloadVersion: '3', messageId: 'msg-1' },
        payload: { scope: { type: 'BearerToken', token: 'tok' } },
      },
    };

    const res = await fetch(`http://127.0.0.1:${PORT}/alexa/directive`, {
      method: 'POST',
      headers: { 'x-api-key': 'test-key', 'Content-Type': 'application/json' },
      body: JSON.stringify(directive),
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.event.header.name).toBe('Discover.Response');
    expect(data.event.payload.endpoints).toHaveLength(1);
  });
```

- [ ] **Step 3: Run tests**

Run: `npx vitest run`
Expected: All pass

- [ ] **Step 4: Commit**

```bash
git add src/api-server.ts test/api-server.test.ts
git commit -m "feat: add /alexa/directive endpoint to API server"
```

---

### Task 9: End-to-End Verification

- [ ] **Step 1: Run full test suite**

Run: `npx vitest run`
Expected: All tests pass

- [ ] **Step 2: Clean build**

Run: `rm -rf dist && npm run build`
Expected: No errors

- [ ] **Step 3: Verify dist structure**

Run: `ls dist/alexa-skill/`
Expected: `handler.js`, `discovery.js`, `control.js` and corresponding `.d.ts`/`.js.map`

- [ ] **Step 4: Verify plugin loads**

Run: `node -e "import('./dist/index.js').then(m => console.log(typeof m.default))"`
Expected: `function`

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "chore: phase 3 complete — Alexa Smart Home Skill with local API"
```
